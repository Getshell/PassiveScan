declare module 'scrollmonitor' {
  export function create(el: HTMLElement): any
}
