EXCLUDES = ["google", "lastpass", '.gov.', 'gvt2.com']
REVERSE_HTTP_IP = "192.168.0.100"  # 回连http IP地址，需要改为服务器ip，不能改为0.0.0.0，因为程序无法识别
REVERSE_HTTP_PORT = 9999  # 回连http端口
REVERSE_RMI_IP = "192.168.0.100"  # Java RMI 回连IP,需要改为服务器ip，不能改为0.0.0.0，因为程序无法识别
REVERSE_RMI_PORT = 10002  # Java RMI 回连端口
REVERSE_DNS = "dnslog.w13scan.hacking8.com"
